package CategoryClassification;

import java.io.File;
import java.util.*;

import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.w3c.dom.Element;
import org.w3c.dom.traversal.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextPane;
//import javax.swing.text.Document;

public class ClassificationMain {
	//private JFrame frame;
	//private JTable table;

	
	
	public static void main(String[] args) {
		ClassificationMain CM = new ClassificationMain();
	}

	public ClassificationMain() {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClassificationFrame window = new ClassificationFrame();
					window.frame.setVisible(true);;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
